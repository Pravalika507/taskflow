import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { searchUsers, getComments, addComment, deleteComment } from '../utils/api';

const initialForm = {
  title: '',
  description: '',
  status: 'todo',
  priority: 'medium',
  dueDate: '',
  members: []
};

function initialsFor(name = '', email = '') {
  const source = name || email || '?';
  const parts = source.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return source.slice(0, 2).toUpperCase();
}

function timeAgo(dateStr) {
  const date = new Date(dateStr);
  const diffMs = Date.now() - date.getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return date.toLocaleDateString();
}

function MembersField({ members, onAdd, onRemove }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const wrapperRef = useRef(null);

  useEffect(() => {
    const onClickOutside = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  useEffect(() => {
    if (!query.trim() || query.trim().length < 2) {
      setResults([]);
      return;
    }
    let active = true;
    setSearching(true);
    const timer = setTimeout(() => {
      searchUsers(query.trim())
        .then((res) => {
          if (!active) return;
          const existingIds = members.map((m) => m._id);
          setResults((res.data.data || []).filter((u) => !existingIds.includes(u._id)));
        })
        .catch(() => active && setResults([]))
        .finally(() => active && setSearching(false));
    }, 300);
    return () => { active = false; clearTimeout(timer); };
  }, [query, members]);

  return (
    <div className="form-group" ref={wrapperRef}>
      <label>Members</label>

      {members.length > 0 && (
        <div className="member-chips">
          {members.map((m) => (
            <span key={m._id} className="member-chip" title={m.email}>
              <span className="member-avatar">{initialsFor(m.name, m.email)}</span>
              <span className="member-chip-name">{m.name || m.email}</span>
              <button
                type="button"
                className="member-chip-remove"
                onClick={() => onRemove(m._id)}
                aria-label={`Remove ${m.name || m.email}`}
              >
                ×
              </button>
            </span>
          ))}
        </div>
      )}

      <div className="member-search-wrap">
        <input
          type="text"
          placeholder="Search by name or email to add a member..."
          value={query}
          onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
        />
        {open && (query.trim().length >= 2) && (
          <div className="member-results">
            {searching && <div className="member-result-empty">Searching...</div>}
            {!searching && results.length === 0 && (
              <div className="member-result-empty">No users found</div>
            )}
            {!searching && results.map((u) => (
              <button
                type="button"
                key={u._id}
                className="member-result-item"
                onClick={() => { onAdd(u); setQuery(''); setResults([]); }}
              >
                <span className="member-avatar">{initialsFor(u.name, u.email)}</span>
                <span>
                  <span className="member-result-name">{u.name}</span>
                  <span className="member-result-email">{u.email}</span>
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function CommentsSection({ taskId, currentUser }) {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    getComments(taskId)
      .then((res) => setComments(res.data.data || []))
      .catch(() => setError('Could not load comments'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (taskId) load();
  }, [taskId]);

  const handlePost = async () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setPosting(true);
    setError('');
    try {
      const res = await addComment(taskId, trimmed);
      setComments((prev) => [...prev, res.data.data]);
      setText('');
    } catch (err) {
      setError(err.response?.data?.message || 'Could not post comment');
    } finally {
      setPosting(false);
    }
  };

  const handleDelete = async (commentId) => {
    try {
      await deleteComment(taskId, commentId);
      setComments((prev) => prev.filter((c) => c._id !== commentId));
    } catch {
      setError('Could not delete comment');
    }
  };

  return (
    <div className="form-group comments-section">
      <label>Comments &amp; Activity</label>

      <div className="comment-list">
        {loading && <div className="comment-empty">Loading comments...</div>}
        {!loading && comments.length === 0 && (
          <div className="comment-empty">No comments yet. Start the discussion.</div>
        )}
        {!loading && comments.map((c) => (
          <div key={c._id} className="comment-item">
            <span className="member-avatar">{initialsFor(c.author?.name, c.author?.email)}</span>
            <div className="comment-body">
              <div className="comment-meta">
                <span className="comment-author">{c.author?.name || c.author?.email || 'Unknown'}</span>
                <span className="comment-time">{timeAgo(c.createdAt)}</span>
              </div>
              <div className="comment-text">{c.text}</div>
            </div>
            {currentUser && c.author?._id === currentUser._id && (
              <button
                type="button"
                className="comment-delete"
                onClick={() => handleDelete(c._id)}
                aria-label="Delete comment"
              >
                ×
              </button>
            )}
          </div>
        ))}
      </div>

      <div className="comment-input-row">
        <textarea
          placeholder="Write a comment..."
          rows={2}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handlePost();
            }
          }}
        />
        <button
          type="button"
          className="btn btn-primary btn-sm"
          onClick={handlePost}
          disabled={posting || !text.trim()}
        >
          {posting ? 'Posting...' : 'Comment'}
        </button>
      </div>
      {error && <span className="field-error">{error}</span>}
    </div>
  );
}

export default function TaskModal({ isOpen, onClose, onSubmit, editingTask, loading }) {
  const { user: currentUser } = useAuth();
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (!isOpen) return;
    if (editingTask) {
      setForm({
        title: editingTask.title || '',
        description: editingTask.description || '',
        status: editingTask.status || 'pending',
        priority: editingTask.priority || 'medium',
        dueDate: editingTask.dueDate ? editingTask.dueDate.split('T')[0] : '',
        members: editingTask.members || []
      });
    } else {
      setForm(initialForm);
    }
    setErrors({});
  }, [isOpen, editingTask]);

  const validate = () => {
    const errs = {};
    const title = form.title.trim();
    if (!title) errs.title = 'Title is required';
    else if (title.length < 3) errs.title = 'Title must be at least 3 characters';
    else if (title.length > 100) errs.title = 'Title cannot exceed 100 characters';
    if (form.description.length > 500) errs.description = 'Description cannot exceed 500 characters';
    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    onSubmit({
      ...form,
      dueDate: form.dueDate || null,
      members: form.members.map((m) => m._id)
    });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const addMember = (user) => {
    setForm((prev) => (
      prev.members.some((m) => m._id === user._id)
        ? prev
        : { ...prev, members: [...prev.members, user] }
    ));
  };

  const removeMember = (userId) => {
    setForm((prev) => ({ ...prev, members: prev.members.filter((m) => m._id !== userId) }));
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal task-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{editingTask ? 'Edit Task' : 'Create New Task'}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div className="modal-body">
            <div className="form-group">
              <label htmlFor="title">
                Title <span className="required">*</span>
              </label>
              <input
                id="title"
                type="text"
                name="title"
                value={form.title}
                onChange={handleChange}
                placeholder="Enter task title"
                className={errors.title ? 'error' : ''}
              />
              {errors.title && <span className="field-error">{errors.title}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={form.description}
                onChange={handleChange}
                placeholder="Optional description..."
                rows={3}
                className={errors.description ? 'error' : ''}
              />
              <div className="char-count">{form.description.length}/500</div>
              {errors.description && <span className="field-error">{errors.description}</span>}
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="status">Status</label>
                <select id="status" name="status" value={form.status} onChange={handleChange}>
                  <option value="todo">Todo</option>
                  <option value="pending">Pending</option>
                  <option value="completed">Completed</option>
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="priority">Priority</label>
                <select id="priority" name="priority" value={form.priority} onChange={handleChange}>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="dueDate">Due Date</label>
              <input
                id="dueDate"
                type="date"
                name="dueDate"
                value={form.dueDate}
                onChange={handleChange}
              />
            </div>

            <MembersField
              members={form.members}
              onAdd={addMember}
              onRemove={removeMember}
            />

            {editingTask && (
              <CommentsSection taskId={editingTask._id} currentUser={currentUser} />
            )}
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-outline" onClick={onClose} disabled={loading}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Saving...' : editingTask ? 'Save Changes' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
