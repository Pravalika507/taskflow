export default function StatsCards({ stats, loading }) {
  const cards = [
    {
      label: 'Total tasks', value: stats?.total ?? 0,
      color: '#6366f1', bg: '#ede9fe',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>
          <polyline points="10 9 9 9 8 9"/>
        </svg>
      )
    },
    {
      label: 'Pending', value: stats?.pending ?? 0,
      color: '#f59e0b', bg: '#fef3c7',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
        </svg>
      )
    },
    {
      label: 'Completed', value: stats?.completed ?? 0,
      color: '#22c55e', bg: '#dcfce7',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"/><polyline points="9 12 11 14 15 10"/>
        </svg>
      )
    },
    {
      label: 'Overdue', value: stats?.overdue ?? 0,
      color: '#ef4444', bg: '#fee2e2',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
          <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
        </svg>
      )
    }
  ];

  return (
    <div className="stats-grid">
      {cards.map(card => (
        <div key={card.label} className="stat-card">
          <div className="stat-card-icon" style={{ color: card.color, background: card.bg }}>
            {card.icon}
          </div>
          <div className="stat-card-value" style={{ color: card.color }}>
            {loading ? '—' : card.value}
          </div>
          <div className="stat-card-label">{card.label}</div>
        </div>
      ))}
    </div>
  );
}
