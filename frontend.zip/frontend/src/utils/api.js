import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' }
});

export const searchUsers = (q) => api.get('/users/search', { params: { q } });

export const getComments = (taskId) => api.get(`/tasks/${taskId}/comments`);
export const addComment = (taskId, text) => api.post(`/tasks/${taskId}/comments`, { text });
export const deleteComment = (taskId, commentId) => api.delete(`/tasks/${taskId}/comments/${commentId}`);

export default api;
