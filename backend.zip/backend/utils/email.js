const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

const sendVerificationEmail = async (name, email, token) => {
  const url = `${process.env.CLIENT_URL}/verify-email?token=${token}`;

  const html = `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Confirm your email</title></head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:32px 0;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;border:1px solid #e0e0e0;">
        <tr>
          <td style="background:#4f46e5;padding:28px 40px;text-align:center;">
            <span style="color:#ffffff;font-size:22px;font-weight:bold;letter-spacing:0.5px;">TaskManager</span>
          </td>
        </tr>
        <tr>
          <td style="padding:36px 40px;">
            <p style="margin:0 0 16px;font-size:16px;color:#111111;">Hi ${name},</p>
            <p style="margin:0 0 16px;font-size:15px;color:#333333;line-height:1.6;">
              Thank you for creating an account with TaskManager. Please confirm your email address by clicking the button below.
            </p>
            <p style="margin:0 0 28px;font-size:15px;color:#333333;line-height:1.6;">
              This link will expire in <strong>24 hours</strong>.
            </p>
            <table cellpadding="0" cellspacing="0">
              <tr>
                <td style="border-radius:6px;background:#4f46e5;">
                  <a href="${url}" style="display:inline-block;padding:14px 32px;color:#ffffff;font-size:15px;font-weight:bold;text-decoration:none;border-radius:6px;">Confirm Email Address</a>
                </td>
              </tr>
            </table>
            <p style="margin:28px 0 0;font-size:13px;color:#888888;line-height:1.6;">
              If the button does not work, copy and paste this link into your browser:<br>
              <a href="${url}" style="color:#4f46e5;word-break:break-all;">${url}</a>
            </p>
            <p style="margin:20px 0 0;font-size:13px;color:#888888;">
              If you did not create this account, you can safely ignore this email.
            </p>
          </td>
        </tr>
        <tr>
          <td style="padding:20px 40px;border-top:1px solid #eeeeee;text-align:center;">
            <p style="margin:0;font-size:12px;color:#aaaaaa;">TaskManager &mdash; karthikabonagiri0715@gmail.com</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

  const text = `Hi ${name},

Thank you for creating an account with TaskManager.

Please confirm your email address by visiting the link below:
${url}

This link will expire in 24 hours.

If you did not create this account, you can safely ignore this email.

-- TaskManager`;

  await transporter.sendMail({
    from: `"TaskManager" <${process.env.SMTP_USER}>`,
    to: email,
    subject: `Confirm your email address`,
    text,
    html,
    headers: {
      'X-Mailer': 'TaskManager Mailer',
      'X-Priority': '3'
    }
  });
};

const sendPasswordResetEmail = async (name, email, token) => {
  const url = `${process.env.CLIENT_URL}/reset-password?token=${token}`;

  const html = `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Reset your password</title></head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:32px 0;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;border:1px solid #e0e0e0;">
        <tr>
          <td style="background:#4f46e5;padding:28px 40px;text-align:center;">
            <span style="color:#ffffff;font-size:22px;font-weight:bold;letter-spacing:0.5px;">TaskManager</span>
          </td>
        </tr>
        <tr>
          <td style="padding:36px 40px;">
            <p style="margin:0 0 16px;font-size:16px;color:#111111;">Hi ${name},</p>
            <p style="margin:0 0 16px;font-size:15px;color:#333333;line-height:1.6;">
              We received a request to reset your TaskManager password.
            </p>
            <p style="margin:0 0 28px;font-size:15px;color:#333333;line-height:1.6;">
              Click the button below to choose a new password. This link expires in <strong>15 minutes</strong>.
            </p>
            <table cellpadding="0" cellspacing="0">
              <tr>
                <td style="border-radius:6px;background:#4f46e5;">
                  <a href="${url}" style="display:inline-block;padding:14px 32px;color:#ffffff;font-size:15px;font-weight:bold;text-decoration:none;border-radius:6px;">Reset Password</a>
                </td>
              </tr>
            </table>
            <p style="margin:28px 0 0;font-size:13px;color:#888888;line-height:1.6;">
              If the button does not work, copy and paste this link into your browser:<br>
              <a href="${url}" style="color:#4f46e5;word-break:break-all;">${url}</a>
            </p>
            <p style="margin:20px 0 0;font-size:13px;color:#888888;">
              If you did not request a password reset, please ignore this email. Your password will not change.
            </p>
          </td>
        </tr>
        <tr>
          <td style="padding:20px 40px;border-top:1px solid #eeeeee;text-align:center;">
            <p style="margin:0;font-size:12px;color:#aaaaaa;">TaskManager &mdash; karthikabonagiri0715@gmail.com</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

  const text = `Hi ${name},

We received a request to reset your TaskManager password.

Click the link below to choose a new password. This link expires in 15 minutes:
${url}

If you did not request a password reset, please ignore this email.

-- TaskManager`;

  await transporter.sendMail({
    from: `"TaskManager" <${process.env.SMTP_USER}>`,
    to: email,
    subject: `Reset your password`,
    text,
    html,
    headers: {
      'X-Mailer': 'TaskManager Mailer',
      'X-Priority': '3'
    }
  });
};

const sendTaskAssignedEmail = async (name, email, task, assignedByName) => {
  const url = `${process.env.CLIENT_URL}/dashboard`;
  const dueText = task.dueDate
    ? new Date(task.dueDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
    : 'No due date';

  const html = `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>You've been assigned a task</title></head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:32px 0;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;border:1px solid #e0e0e0;">
        <tr>
          <td style="background:#4f46e5;padding:28px 40px;text-align:center;">
            <span style="color:#ffffff;font-size:22px;font-weight:bold;letter-spacing:0.5px;">TaskManager</span>
          </td>
        </tr>
        <tr>
          <td style="padding:36px 40px;">
            <p style="margin:0 0 16px;font-size:16px;color:#111111;">Hi ${name},</p>
            <p style="margin:0 0 16px;font-size:15px;color:#333333;line-height:1.6;">
              <strong>${assignedByName}</strong> assigned you a task on TaskManager:
            </p>
            <table cellpadding="0" cellspacing="0" width="100%" style="border:1px solid #eeeeee;border-radius:6px;margin:0 0 24px;">
              <tr>
                <td style="padding:16px 20px;">
                  <p style="margin:0 0 8px;font-size:15px;font-weight:bold;color:#111111;">${task.title}</p>
                  ${task.description ? `<p style="margin:0 0 8px;font-size:14px;color:#555555;line-height:1.5;">${task.description}</p>` : ''}
                  <p style="margin:0;font-size:13px;color:#888888;">Priority: ${task.priority} &nbsp;|&nbsp; Due: ${dueText}</p>
                </td>
              </tr>
            </table>
            <table cellpadding="0" cellspacing="0">
              <tr>
                <td style="border-radius:6px;background:#4f46e5;">
                  <a href="${url}" style="display:inline-block;padding:14px 32px;color:#ffffff;font-size:15px;font-weight:bold;text-decoration:none;border-radius:6px;">View Task</a>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="padding:20px 40px;border-top:1px solid #eeeeee;text-align:center;">
            <p style="margin:0;font-size:12px;color:#aaaaaa;">TaskManager &mdash; karthikabonagiri0715@gmail.com</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

  const text = `Hi ${name},

${assignedByName} assigned you a task on TaskManager:

${task.title}
${task.description ? task.description + '\n' : ''}Priority: ${task.priority} | Due: ${dueText}

View it here: ${url}

-- TaskManager`;

  await transporter.sendMail({
    from: `"TaskManager" <${process.env.SMTP_USER}>`,
    to: email,
    subject: `${assignedByName} assigned you a task: ${task.title}`,
    text,
    html,
    headers: {
      'X-Mailer': 'TaskManager Mailer',
      'X-Priority': '3'
    }
  });
};

module.exports = { sendVerificationEmail, sendPasswordResetEmail, sendTaskAssignedEmail };
